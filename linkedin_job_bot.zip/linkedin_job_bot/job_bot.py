"""
LinkedIn Job Bot
----------------
Fetches jobs via RapidAPI's LinkedIn Job Search endpoint,
scores them against your resume with Claude, then emails you a daily digest.

Setup:
  pip install anthropic requests python-dotenv
  Copy .env.example → .env and fill in your credentials.
"""

import json
import smtplib
import os
from datetime import date
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import anthropic
import requests
from dotenv import load_dotenv

load_dotenv()

# ── Config ────────────────────────────────────────────────────────────────────

RAPIDAPI_KEY      = os.getenv("RAPIDAPI_KEY")          # RapidAPI key
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")     # Anthropic key

# Job search parameters
JOB_KEYWORDS      = os.getenv("JOB_KEYWORDS", "Software Engineer")
JOB_LOCATION      = os.getenv("JOB_LOCATION", "New York")
SALARY_MIN        = int(os.getenv("SALARY_MIN", "100000"))  # USD
RELEVANCE_CUTOFF  = int(os.getenv("RELEVANCE_CUTOFF", "7")) # Score 1-10

# Email settings
SMTP_HOST     = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT     = int(os.getenv("SMTP_PORT", "587"))
EMAIL_SENDER  = os.getenv("EMAIL_SENDER")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")  # Gmail: use an App Password
EMAIL_TO      = os.getenv("EMAIL_TO")

RESUME_FILE = "resume.txt"  # Path to your plain-text resume

# ── Fetch Jobs ────────────────────────────────────────────────────────────────

def fetch_jobs(keywords: str, location: str, limit: int = 25) -> list[dict]:
    """
    Calls the LinkedIn Job Search API via RapidAPI.
    Free tier: 100 requests/month — plenty for daily use.
    API docs: https://rapidapi.com/jaypat87/api/linkedin-jobs-search
    """
    url = "https://linkedin-jobs-search.p.rapidapi.com/"
    headers = {
        "content-type": "application/json",
        "X-RapidAPI-Key": RAPIDAPI_KEY,
        "X-RapidAPI-Host": "linkedin-jobs-search.p.rapidapi.com",
    }
    payload = {
        "search_terms": keywords,
        "location": location,
        "page": "1",
    }

    response = requests.post(url, json=payload, headers=headers, timeout=15)
    response.raise_for_status()
    jobs = response.json()

    # Normalize to a consistent schema
    normalized = []
    for j in jobs[:limit]:
        normalized.append({
            "title":       j.get("job_title", "N/A"),
            "company":     j.get("company_name", "N/A"),
            "location":    j.get("job_location", "N/A"),
            "description": j.get("job_description", ""),
            "salary":      j.get("salary", "Not listed"),
            "url":         j.get("linkedin_job_url", "#"),
            "posted":      j.get("posted_date", "N/A"),
        })
    return normalized


# ── Score Jobs with Claude ─────────────────────────────────────────────────────

def score_job(client: anthropic.Anthropic, job: dict, resume: str, salary_min: int) -> dict | None:
    """
    Ask Claude to rate this job 1-10 against the candidate's resume.
    Returns the job dict enriched with score/reason, or None if below cutoff.
    """
    prompt = f"""You are a career coach evaluating job fit.

RESUME:
{resume}

JOB POSTING:
Title:       {job['title']}
Company:     {job['company']}
Location:    {job['location']}
Salary:      {job['salary']}
Description: {job['description'][:2000]}

CANDIDATE'S MINIMUM SALARY: ${salary_min:,}

Score this job's fit for the candidate from 1-10 where:
- 10 = perfect match (skills align, seniority matches, salary likely meets minimum)
- 7-9 = strong candidate with minor gaps
- 4-6 = partial match, significant gaps
- 1-3 = poor fit

If the salary is explicitly listed and below ${salary_min:,}, cap the score at 4.

Respond ONLY with valid JSON, no markdown, no explanation outside the JSON:
{{
  "score": <integer 1-10>,
  "match_reasons": ["reason 1", "reason 2"],
  "concerns": ["concern 1"],
  "salary_note": "<brief salary comment or 'Salary not listed'>",
  "apply": <true if score >= {RELEVANCE_CUTOFF}>
}}"""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=400,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = response.content[0].text.strip()
        analysis = json.loads(raw)
        if analysis.get("apply"):
            return {**job, **analysis}
    except (json.JSONDecodeError, KeyError, anthropic.APIError) as e:
        print(f"  ⚠ Skipping '{job['title']}' at {job['company']}: {e}")
    return None


# ── Build Email ───────────────────────────────────────────────────────────────

def build_email_html(jobs: list[dict], run_date: str) -> str:
    score_color = lambda s: "#16a34a" if s >= 8 else "#ca8a04" if s >= 6 else "#dc2626"

    cards = ""
    for j in jobs:
        reasons_html = "".join(f"<li>{r}</li>" for r in j.get("match_reasons", []))
        concerns_html = "".join(f"<li>{c}</li>" for c in j.get("concerns", []))
        score = j.get("score", 0)
        cards += f"""
        <div style="border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin-bottom:16px;background:#fff;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;">
            <div>
              <h2 style="margin:0 0 4px;font-size:18px;color:#111827;">{j['title']}</h2>
              <p style="margin:0;color:#6b7280;font-size:14px;">{j['company']} · {j['location']}</p>
              <p style="margin:4px 0 0;color:#6b7280;font-size:13px;">💰 {j['salary']} &nbsp;|&nbsp; 🗓 Posted: {j['posted']}</p>
            </div>
            <div style="text-align:center;background:{score_color(score)};color:#fff;
                        border-radius:50%;width:48px;height:48px;line-height:48px;
                        font-size:20px;font-weight:700;flex-shrink:0;margin-left:12px;">
              {score}
            </div>
          </div>
          <div style="margin-top:14px;display:flex;gap:24px;">
            <div style="flex:1;">
              <p style="margin:0 0 6px;font-weight:600;font-size:13px;color:#111827;">✅ Why you're a fit</p>
              <ul style="margin:0;padding-left:18px;font-size:13px;color:#374151;">{reasons_html}</ul>
            </div>
            {"" if not concerns_html else f'''
            <div style="flex:1;">
              <p style="margin:0 0 6px;font-weight:600;font-size:13px;color:#111827;">⚠️ Potential gaps</p>
              <ul style="margin:0;padding-left:18px;font-size:13px;color:#374151;">{concerns_html}</ul>
            </div>'''}
          </div>
          <p style="margin:12px 0 0;font-size:12px;color:#9ca3af;">{j.get('salary_note','')}</p>
          <a href="{j['url']}" style="display:inline-block;margin-top:12px;padding:8px 16px;
             background:#0a66c2;color:#fff;text-decoration:none;border-radius:6px;font-size:13px;font-weight:600;">
            View on LinkedIn →
          </a>
        </div>"""

    return f"""
    <html><body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
                       background:#f9fafb;margin:0;padding:24px;">
      <div style="max-width:680px;margin:0 auto;">
        <h1 style="color:#111827;font-size:24px;margin-bottom:4px;">🔍 Your Daily Job Matches</h1>
        <p style="color:#6b7280;margin:0 0 24px;">{run_date} · {len(jobs)} job{"s" if len(jobs)!=1 else ""} scoring {RELEVANCE_CUTOFF}+ for <strong>{JOB_KEYWORDS}</strong> in <strong>{JOB_LOCATION}</strong></p>
        {cards if cards else '<p style="color:#6b7280;">No strong matches found today. Try broadening your keywords.</p>'}
        <p style="color:#9ca3af;font-size:12px;margin-top:32px;">Sent by your LinkedIn Job Bot · Edit job_bot.py to adjust settings</p>
      </div>
    </body></html>"""


# ── Send Email ────────────────────────────────────────────────────────────────

def send_email(html_body: str, job_count: int, run_date: str):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"[Job Bot] {job_count} match{'es' if job_count != 1 else ''} for {JOB_KEYWORDS} — {run_date}"
    msg["From"]    = EMAIL_SENDER
    msg["To"]      = EMAIL_TO
    msg.attach(MIMEText(html_body, "html"))

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
        server.ehlo()
        server.starttls()
        server.login(EMAIL_SENDER, EMAIL_PASSWORD)
        server.sendmail(EMAIL_SENDER, EMAIL_TO, msg.as_string())
    print(f"✅ Email sent to {EMAIL_TO}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    run_date = date.today().strftime("%B %d, %Y")
    print(f"\n{'='*50}")
    print(f"  LinkedIn Job Bot — {run_date}")
    print(f"{'='*50}")

    # Load resume
    if not os.path.exists(RESUME_FILE):
        raise FileNotFoundError(
            f"'{RESUME_FILE}' not found. Create it with your resume as plain text."
        )
    with open(RESUME_FILE) as f:
        resume = f.read()
    print(f"📄 Resume loaded ({len(resume)} chars)")

    # Fetch jobs
    print(f"\n🔍 Searching: '{JOB_KEYWORDS}' in '{JOB_LOCATION}'...")
    jobs = fetch_jobs(JOB_KEYWORDS, JOB_LOCATION)
    print(f"   Found {len(jobs)} postings")

    # Score with Claude
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    matched = []
    print(f"\n🤖 Scoring with Claude (cutoff: {RELEVANCE_CUTOFF}/10, salary min: ${SALARY_MIN:,})...")
    for i, job in enumerate(jobs, 1):
        print(f"   [{i}/{len(jobs)}] {job['title']} @ {job['company']}", end=" ... ")
        result = score_job(client, job, resume, SALARY_MIN)
        if result:
            print(f"✅ {result['score']}/10")
            matched.append(result)
        else:
            print("skip")

    matched.sort(key=lambda x: x["score"], reverse=True)
    print(f"\n📊 {len(matched)} job(s) met your criteria")

    # Send email
    html = build_email_html(matched, run_date)
    print("\n📧 Sending digest email...")
    send_email(html, len(matched), run_date)


if __name__ == "__main__":
    main()
